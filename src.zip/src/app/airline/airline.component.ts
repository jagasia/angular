import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-airline',
  templateUrl: './airline.component.html',
  styleUrls: ['./airline.component.css']
})
export class AirlineComponent implements OnInit {
  airlineForm:any;

  constructor(private fb:FormBuilder) {
    this.airlineForm=fb.group({
      id:[''],
      name:[''],
      country:[''],
      logo:[''],
      slogon:[''],
      head_quarters:[''],
      website:[''],
      established:['']
    });
   }

  ngOnInit(): void {
  }

}
