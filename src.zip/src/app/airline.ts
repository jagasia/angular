export class Airline {
    id:number=8;
    name:string="Thai Airways";
    country:string="Thailand";
    logo:string="";
    slogon:string="";
    head_quarters:string="";
    website:string="";
    established:number=2021;
}
