import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AirlineComponent } from './airline/airline.component';
import { BranchComponent } from './branch/branch.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [
  {path:'branch',component:BranchComponent},
  {path:'airline',component:AirlineComponent},
  {path:'login',component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
