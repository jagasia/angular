package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Branch;
import com.example.demo.repository.BranchRepository;

@Service
public class BranchService {
	@Autowired
	private BranchRepository br;
	
	public Branch create(Branch branch) {
		return br.save(branch);
	}
	public List<Branch> read() {
		return br.findAll();
	}
	public Branch read(String bid) {
		return br.findById(bid).get();
	}
	public Branch update(Branch branch) {
		return br.save(branch);
	}
	public void delete(Branch branch) {
		br.delete(branch);
	}
	

}
