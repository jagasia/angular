import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AirlineService } from '../airline.service';

@Component({
  selector: 'app-airline',
  templateUrl: './airline.component.html',
  styleUrls: ['./airline.component.css']
})
export class AirlineComponent implements OnInit {
  airlineForm:any;
  airlines:any;


  constructor(private fb:FormBuilder, private as:AirlineService) {
    this.airlineForm=fb.group({
      id:[''],
      name:[''],
      country:[''],
      logo:[''],
      slogan:[''],
      head_quaters:[''],
      website:[''],
      established:['']
    });
   }

  ngOnInit(): void {
    this.as.readAllAirlines().subscribe((data)=>{this.airlines=data});
  }

  fnSelect(id:number)
  {
    this.as.findAirlineById(id).subscribe((data)=>{
      //i am going to patch this object into the FORM
      this.airlineForm.patchValue(data);
    });
  }

  fnAdd()
  {
    //the entire form should be rep as an object and send that object to the rest api
    var airline=this.airlineForm.value;   //this is the object of airline (form)
    console.log("Sending new object:");
    console.log(JSON.stringify(airline));
    this.as.addAirline(airline).subscribe(data=>console.log(data));
  }
}
