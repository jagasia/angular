import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'aj0073';

  fnLogin(data)
  {
    // alert("Parent has received data: "+data);
    var arr=data.split(":");
    alert(arr[0])
    alert(arr[1])
  }
}
